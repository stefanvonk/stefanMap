# detect-kippo-cowrie
Proof of concept written in Python to detect Kippo and Cowrie SSH honeypots.
