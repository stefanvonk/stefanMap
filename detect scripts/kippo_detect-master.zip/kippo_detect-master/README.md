kippo_detect
============

Quick proof of concept to detect a Kippo SSH honeypot instance externally

### Usage

```
# python kippo_detect.py 1.1.1.1
[!] Kippo honeypot detected!
```

