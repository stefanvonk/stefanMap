HONEYBEE :- Only A Bee Can Detect Real Honey
* Honeybee.py :-Starting Script which scans the newtork by taking hosts , ports and arguments and displayes the Operating system running , Open-Ports and also the servies running on them.
* Kippo.py :- Detects the Kippo Honeypot . A ssh honeypot running on port 22 by default (although one can anytime change the default ports XD !!)
* Glastopf.py :- Detects web honeypot namely glastopf. Local file intrusion (LFI) vulnerability is present in the same .
* Amun.py :- A Multipurpose honeypot but easily detectable as Microsoft services are running like IIS service etc and many services are not properly enumerated .
* Some More Honeypots like Nova , Dionaea , Honeyd etc are also not fully patched against easily detectable intrusions .
